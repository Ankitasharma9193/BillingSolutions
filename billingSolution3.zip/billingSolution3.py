# Ankita Sharma

import pymongo

connection = pymongo.MongoClient("mongodb+srv://Anshu:anshu123@billingsolution.kkjaf.mongodb.net/BillingSolution?retryWrites=true&w=majority")
database = connection['BillingSolution']

collection = database['Invoice']
collection2 = database['Credentials']
collection3 = database['Comment']

data = [{ "Invoice Number": 425745, "Payment date": "12/07/2020", "Derived Product Cost": 123, "GST": 1, "PST": 1.3, "Total Cost" :125.3},
        { "Invoice Number": 485961, "Payment date": "06/04/2020", "Derived Product Cost": 12.3, "GST": 0.1, "PST": 0.13, "Total Cost": 12.53},
        { "Invoice Number": 412586, "Payment date": "06/04/2020", "Derived Product Cost": 212.3, "GST": 21, "PST": 13, "Total Cost": 246.3},
        { "Invoice Number": 254103, "Payment date": "22/12/2019", "Derived Product Cost": 19.3, "GST": 2.1, "PST": 1.3, "Total Cost": 22.7},
        { "Invoice Number": 415287, "Payment date": "12/10/2019", "Derived Product Cost": 16.99, "GST": 1.0, "PST": 1.3, "Total Cost": 19.29},
        { "Invoice Number": 472531, "Payment date": "22/08/2020", "Derived Product Cost": 23, "GST": 2.5, "PST": 1.3, "Total Cost" :26.8},
        { "Invoice Number": 741520, "Payment date": "06/08/2020", "Derived Product Cost": 220, "GST": 21, "PST": 5.7,   "Total Cost": 246.7},
        { "Invoice Number": 245862, "Payment date": "01/06/2020", "Derived Product Cost": 15.99, "GST": 2.99, "PST": 1.02, "Total Cost": 18.00},
        { "Invoice Number": 741253, "Payment date": "16/11/2019", "Derived Product Cost": 10, "GST": 1.3, "PST": 1.2, "Total Cost": 12.5},
        { "Invoice Number": 452301, "Payment date": "28/03/2020", "Derived Product Cost": 25.99, "GST": 3.0, "PST": 2.1, "Total Cost": 31.00}]

data2 = [{ "Registered Email": "ankitasharma9193@gmail.com", "Password": "Ankita@9193"},
         { "Registered Email": "ashikajhanwar@gmail.com", "Password": "Ashika@8787"},
         { "Registered Email": "rajnm@gmail.com", "Password": "Rajn@8787"},
         {"Registered Email": "burjo@gmail.com", "Password": "Bur34**q"},
         {"Registered Email": "kittynathan@gmail.com", "Password": "knathan#eqw"},
         {"Registered Email": "Priyabedi98@gmail.com", "Password": "priya@123"},
         {"Registered Email": "jagjeetsingh@gmail.com", "Password": "Jagjeet@7458"},
         {"Registered Email": "hiraksahni89@gmail.com", "Password": "pwd@3455"},
         {"Registered Email": "charles234@gmail.com", "Password": "charlesds@456"},
         {"Registered Email": "Jacksebastian789", "Password": "huhyhu#eqw"}]

date3 = [{"Note" : "Please buzz in code #777 and deliver the product to concierge in case I won't pick the call"},
         {"Note" : ""},
         {"Note": ""},
         {"Note": "Please hand the package to a receptionist"},
         {"Note": "Ring the bell"},
         {"Note": "Kindly leave at the door after ringing the bell"},
         {"Note": ""},
         {"Note": "Product quality not good."},
         {"Note": "Please hand the package to a receptionist"},
         {"Note": "Put the parcel in the mailbox and ring the bell"}]

def insertData(data):
    collection.insert_many(data)

def insertData2(data):
    collection2.insert_many(data)

def insertData3(data):
    collection3.insert_many(data)

#insertData(data)
#insertData2(data2)
#insertData3(date3)

def readData():
    invoices = collection.find()
    credentials = collection2.find()
    comments = collection3.find()

    print("All data from invoice")
    for invoice in invoices:
        print(invoice)

    print("All data of credentials")
    for credential in credentials:
        print(credential)

    print("All data of comment")
    for comment in comments:
        print(comment)

#readData()

def updateData():
    collection.update_one(
        {"Invoice Number": 425745},
        {
            "$set": {
                "Payment date": "12/07/2020",
                "Derived Product Cost": 120,
            }
        })


#updateData()

def deleteData():
    query = ({"Invoice Number": 485961})
    collection.delete_one(query)

    query1 = ({"Registered Email": "kittynathan@gmail.com"})
    collection2.delete_many(query1)

deleteData()



